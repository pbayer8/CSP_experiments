
// IIFE - Immediately Invoked Function Expression
(function($, window, document) {

    // The $ is now locally scoped 

    // Listen for the jQuery ready event on the document
    $(function() {
        // The DOM is ready!
        setTextHeight();
        var input = $('#input');
        var background = $('#background');
        var word = '';
        var lastWord = '';
        input.bind('input propertychange', function() {
            var text = input.val();
            var words = text.split(/\W+/);
            lastWord = word;
            console.log('lastword :' + word + ':');
            word = words[words.length - 1];
            if (!word.length)
                word = words[words.length - 2];
            if (lastWord != word) {
                console.log('word :' + word + ':');
                $('iframe#backframe').attr('src', 'http://' + word + '.com');
            }
            background.val(text + text.slice(0, 10) + '\n\n\n\n');
            if (input.length)
                background.scrollTop(input.scrollTop());
        });
    });

    function setTextHeight() {
        var height = $(window).height();
        $('#input').outerHeight(height / 2);
        $('#background').outerHeight(height);
    }

    // function setSelectionRange(input, selectionStart, selectionEnd) {
    //     if (input.setSelectionRange) {
    //         input.focus();
    //         input.setSelectionRange(selectionStart, selectionEnd);
    //     } else if (input.createTextRange) {
    //         var range = input.createTextRange();
    //         range.collapse(true);
    //         range.moveEnd('character', selectionEnd);
    //         range.moveStart('character', selectionStart);
    //         range.select();
    //     }
    // }

    function setCaretToPos(input, pos) {
        setSelectionRange(input, pos, pos);
    }

    $("#set-textarea").click(function() {
        setCaretToPos($("#the-textarea")[0], 10)
    });
    // The rest of the code goes here!
    $(window).resize(setTextHeight);


}(window.jQuery, window, document));
// The global jQuery object is passed as a parameter